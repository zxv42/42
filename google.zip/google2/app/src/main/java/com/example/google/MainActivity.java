package com.example.a8;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    Button runWebsite = findViewById(R.id.runWebsite);
    EditText website = findViewById(R.id.website);
    runWebsite.setOnClickListener(view -> {
        String strURL = website.getText().toString().trim();
        if (strURL.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a URL",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (!strURL.matches("^(http://|https://).*")) {
            strURL = "https://" + strURL; }
        Intent implicit = new Intent(Intent.ACTION_VIEW, Uri.parse(strURL));
        startActivity(implicit);
    });
}
}